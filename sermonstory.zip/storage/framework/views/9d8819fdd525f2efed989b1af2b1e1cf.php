<?php

use Livewire\Volt\Component;
use App\Models\CategoryTag;
use Livewire\Attributes\Rule;
use App\Models\GptStory;
use App\Models\GptScripture;
use Illuminate\Support\Facades\DB;

?>

<div class="overflow-hidden rounded shadow-sm">

    <div wire:loading class="fixed top-0 left-0 w-full h-full bg-gray-300 backdrop-blur-sm bg-opacity-80 z-50 flex justify-center items-center">
        <div class="text-white flex items-center h-full justify-center text-lg font-semibold">
            <div class="loader">
                <span class="loading bg-orange-800 loading-ring loading-lg"></span>
            </div>
        </div>
    </div>

    <div class="p-2 sm:p-4 bg-gray-50 border-b border-gray-200">
        <h2 class="font-semibold text-center text-xl sm:text-2xl mb-4">Generate a Story</h2>
        <form wire:submit.prevent="generate">
            <?php echo csrf_field(); ?>

            <!-- Title -->
            <div class="mb-4">
                <label class="block text-gray-700 text-sm font-semibold mb-2" for="title">Enter a title</label>
                <input type="text" wire:model="title" class="border border-gray-300 rounded px-2 py-1 w-full" placeholder="Title eg A story about Joe">
                <!-- __BLOCK__ --><?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!-- __ENDBLOCK__ -->
            </div>

            <!-- Categories -->
            <div class="mb-4">
                <label class="block text-gray-700 text-sm font-semibold mb-2">Select Categories (Up to 3):</label>
                <div class="flex flex-wrap relative">
                    <!-- __BLOCK__ --><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <button type="button"
                                wire:click="toggleCategory(<?php echo e($category->id); ?>)"
                                class="border text-sm hover:bg-blue-400 rounded px-2 py-1 mr-1 mb-1 focus:outline-none
                           <?php echo e(in_array($category->id, $selectedCategories) ? 'bg-blue-500 text-white' : 'border-gray-300'); ?>

                           <?php echo e(count($selectedCategories) >= 3 && !in_array($category->id, $selectedCategories) ? 'bg-gray-200' : ''); ?>">
                            <?php echo e($category->name); ?>

                        </button>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!-- __ENDBLOCK__ -->
                </div>

                <!-- __BLOCK__ --><?php $__errorArgs = ['selectedCategories'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!-- __ENDBLOCK__ -->
                <input type="hidden" name="selected_categories" value="<?php echo e(implode(',', $selectedCategories)); ?>">
            </div>

            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.secondary-button','data' => ['type' => 'submit','class' => 'ring-blue-500 ring-2 hover:bg-gray-100']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('secondary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'submit','class' => 'ring-blue-500 ring-2 hover:bg-gray-100']); ?>
                Generate Story

                <div wire:loading>
                    <i class="fas fa-spinner fa-spin"></i>
                </div>

             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
        </form>

        <!-- Display generated story -->

        <!--if showStory is true, display the story-->

        <!-- __BLOCK__ --><?php if($showStory): ?>
            <div class="p-2 bg-gray-100 flex flex-col gap-3 rounded mt-4">
                <div class="top mb-2">
                    <h3 class="text-center text-2xl font-semibold"><?php echo e($generatedTitle); ?></h3>
                    <p>
                        <?php echo e($generatedStory); ?>

                    </p>
                </div>
                <div class="mid mb-2">
                    <h3 class="text-center text-2xl font-semibold">Moral Lesson</h3>
                    <p>
                        <?php echo e($lesson); ?>

                    </p>
                </div>

                <div class="Bottom">

                    <h3 class="text-center text-2xl font-semibold">Verses</h3>
                    <pre><?php echo e($verses); ?></pre>
                </div>
            </div>
        <?php endif; ?> <!-- __ENDBLOCK__ -->

    </div>


</div><?php /**PATH D:\Apps\sermonstory\resources\views\livewire/gptgenerate.blade.php ENDPATH**/ ?>
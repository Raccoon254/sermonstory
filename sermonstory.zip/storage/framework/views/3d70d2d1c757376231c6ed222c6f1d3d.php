<div class="drawer w-0 md:w-64 md:drawer-open">
    <input id="my-drawer" type="checkbox" class="drawer-toggle" />
    <div class="">

    </div>
    <div class="z-40 drawer-side">
        <label for="my-drawer" class="drawer-overlay"></label>
        <div class="flex flex-col h-screen border-r border-gray-200 bg-base-100 justify-between">

            <div class="test"></div>

            <div class="menu overflow-clip p-4 w-64 backdrop-blur-sm bg-gray-50 bg-opacity-30 text-base-content gap-4 flex flex-col justify-center items-center">
                <!-- App Logo -->
                <div class="flex items-center w-full justify-center gap-4">
                    <a href="<?php echo e(route('home')); ?>">
                        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.application-logo','data' => ['class' => 'block w-[60px] fill-current text-gray-800']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('application-logo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'block w-[60px] fill-current text-gray-800']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                    </a>
                </div>

                <!-- Sidebar content here -->
                <a href="<?php echo e(route('home')); ?>" class="side <?php echo e(Route::is('home') ? 'active' : ''); ?>">
                    <i class="fa-solid fa-home-lg"></i>
                    <div class="">
                        Dashboard
                    </div>
                </a>

                <a href="<?php echo e(route('profile')); ?>" class="side <?php echo e(Route::is('profile') ? 'active' : ''); ?>">
                    <i class="fa-regular fa-circle-user"></i>
                    <div class="">
                        Profile
                    </div>
                </a>

                <a href="<?php echo e(route('stories.index')); ?>" class="side <?php echo e(Route::is('stories.index') ? 'active' : ''); ?>">
                    <i class="fa-solid fa-book"></i>
                    <div class="">
                        Stories
                    </div>
                </a>

                <a href="<?php echo e(route('about')); ?>" class="side <?php echo e(Route::is('about') ? 'active' : ''); ?>">
                    <i class="fa-solid fa-info"></i>
                    <div class="">
                        About
                    </div>
                </a>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage')): ?>

                    <a href="<?php echo e(route('stories.create')); ?>" class="side <?php echo e(Route::is('stories.create') ? 'active' : ''); ?>">
                        <i class="fa-solid fa-plus"></i>
                        <div class="">
                            Create
                        </div>
                    </a>

                <?php endif; ?>


                <a class="side" href="">
                    <i class="fa-solid fa-bell"></i>
                    <div class="">
                        Notifications
                    </div>
                </a>


            </div>
            <div class="menu overflow-clip p-4 w-64 backdrop-blur-sm bg-gray-50 bg-opacity-30 text-base-content gap-4 flex flex-col justify-center items-center">
                <!--Logout-->
                <?php if(auth()->user()): ?>
                    <form wire:submit.prevent="logout" class="side d-inline ring bg-blue-300">
                        <i class="fa-solid fa-sign-out"></i>
                        <div class="">
                            Logout
                        </div>
                    </form>
                <?php endif; ?>
            </div>
        </div>

    </div>
</div>
<?php /**PATH D:\Apps\sermonstory\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Dashboard')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">

        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 mb-4">
            <div class="bg-gray-50 overflow-hidden shadow-sm">
                <div class="p-6 flex flex-col text-gray-900">
                    Select a story category to get started. Get our carefully curated stories written by our authors and bring your sermon audience to life.
                    <div class="flex gap-4 my-3 actions">
                        <a href="<?php echo e(route('stories.index')); ?>">
                            <button class="btn btn-md btn-primary ring">
                                <i class="fa-solid fa-pen-nib"></i> Author Stories
                            </button>
                        </a>
                        <a href="<?php echo e(route('gptstories.index')); ?>">
                            <button class="btn btn-md btn-outline ring ring-blue-500">
                                <i class="fa-solid fa-mountain"></i> GPT Stories
                            </button>
                        </a>
                    </div>
                </div>
            </div>
        </div>


        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 mb-4">
            <div class="bg-gray-50 overflow-hidden shadow-sm">
                <div class="p-6 flex flex-col text-gray-900">
                    By using our AI powered story generator, you can create a story in seconds. Simply enter a title and select up to 3 categories and we'll do the rest.

                    <a href="<?php echo e(route('generate.story')); ?>" class="mt-4 inline-block font-bold py-2 rounded">
                        <button class="btn btn-md btn-outline ring ring-blue-500">
                            <i class="fa-solid fa-forward"></i> Generate a Story
                        </button>
                    </a>
                </div>
            </div>
        </div>

    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Apps\sermonstory\resources\views/dashboard.blade.php ENDPATH**/ ?>
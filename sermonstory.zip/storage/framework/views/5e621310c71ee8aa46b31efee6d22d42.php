<?php

use Livewire\Volt\Component;

?>

<nav class="bg-white border-b border-gray-100">

    <header class="flex justify-between items-center p-3">

        <section class="start">

        </section>

        <nav class="flex gap-3">
            <a href="<?php echo e(route('home')); ?>" class="<?php echo e(Route::currentRouteName() == 'home' ? 'text-blue-500' : ''); ?>">Home</a>
            <a href="<?php echo e(route('dashboard')); ?>" class="<?php echo e(Route::currentRouteName() == 'dashboard' ? 'text-blue-500' : ''); ?>">Dashboard</a>
            <a href="<?php echo e(route('stories.index')); ?>" class="<?php echo e(Route::currentRouteName() == 'stories.index' ? 'text-blue-500' : ''); ?>">Stories</a>
            <a href="<?php echo e(route('about')); ?>" class="<?php echo e(Route::currentRouteName() == 'about' ? 'text-blue-500' : ''); ?>">About</a>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage')): ?>
                <a href="<?php echo e(route('stories.create')); ?>" class="<?php echo e(Route::currentRouteName() == 'stories.create' ? 'text-blue-500' : ''); ?>">Create</a>
            <?php endif; ?>
        </nav>

        <section class="flex end justify-end">

            <!-- __BLOCK__ --><?php if(auth()->user()): ?>
                <form wire:submit.prevent="logout" class="d-inline">
                    <button type="submit" class="btn btn-circle btn-sm btn-outline">
                        <i class="fa-solid fa-sign-out"></i>
                    </button>
                </form>
            <?php endif; ?> <!-- __ENDBLOCK__ -->

        </section>

    </header>


</nav><?php /**PATH C:\Apps\sermonstory\resources\views\livewire/layout/navigation.blade.php ENDPATH**/ ?>
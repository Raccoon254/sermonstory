<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <!--title and meta description-->
     <?php $__env->slot('title', null, []); ?> <?php echo e($story->title); ?> <?php $__env->endSlot(); ?>
     <?php $__env->slot('description', null, []); ?> <?php echo e(Str::limit($story->content, 160)); ?> <?php $__env->endSlot(); ?> <!-- Limiting description to 160 chars -->


    <div class="min-h-screen flex items-center justify-center bg-cover bg-center relative">
            <!-- Use a semi-transparent overlay to make the text more readable -->
            <div class="absolute inset-0 bg-gray-50 rounded opacity-40"></div>

            <div class="relative z-10 max-w-2xl p-6 backdrop-blur-sm bg-base-100 bg-opacity-10 rounded shadow-sm">
                <h1 class="text-3xl font-semibold mb-4"><?php echo e($story->title); ?></h1>
                <p class="mb-4"><?php echo e($story->content); ?></p>

                <?php if($story->moral_lesson): ?>
                    <div class="mt-4">
                        <h2 class="text-xl font-semibold mb-2">Moral Lesson:</h2>
                        <p><?php echo e($story->moral_lesson); ?></p>
                    </div>
                <?php endif; ?>

                <?php if($story->conclusion): ?>
                    <div class="mt-4">
                        <h2 class="text-xl font-semibold mb-2">Conclusion:</h2>
                        <p><?php echo e($story->conclusion); ?></p>
                    </div>
                <?php endif; ?>

                <?php if($story->scriptures->count()): ?>
                    <div class="mt-4">
                        <h2 class="text-xl font-semibold mb-2">Scriptures:</h2>
                        <?php $__currentLoopData = $story->scriptures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $scripture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <p class="mb-2"><?php echo e($scripture->content); ?></p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>

                <div class="flex justify-between items-center">
                    <?php if($story->categoryTags->count()): ?>
                        <div class="mt-4 flex flex-wrap gap-2">
                            <?php $__currentLoopData = $story->categoryTags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class="tag bg-gray-200 p-1 rounded"><?php echo e($tag->name); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>

                    <div class="mt-4">
                        <a href="<?php echo e(route('stories.index')); ?>">
                            <button class="btn btn-outline btn-ghost h-10 rounded-0  ring ring-inset ring-white">
                                <i class="fa-regular fa-circle-left"></i> Back
                            </button>
                        </a>
                    </div>

                </div>
            </div>
        </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\Apps\sermonstory\resources\views/stories/show.blade.php ENDPATH**/ ?>
<div class="sm:fixed sm:top-0 sm:right-0 p-6 text-right z-10">
    <!-- __BLOCK__ --><?php if(auth()->guard()->check()): ?>
        <a data-tip="Dashboard" href="<?php echo e(url('/dashboard')); ?>" class="btn text-gray-50 rounded btn-outline ring ring-inset font-semibold focus:outline-none focus:ring-2 focus:ring-red-500" wire:navigate>
            <i class="fas fa-tachometer-alt mr-1"></i> Dashboard
        </a>
    <?php else: ?>
        <a href="<?php echo e(route('login')); ?>" class="btn text-gray-50 rounded btn-outline ring ring-inset font-semibold focus:outline-none focus:ring-2 focus:ring-red-500" wire:navigate>
            <i class="fas fa-sign-in-alt mr-1"></i> Log in
        </a>

        <!-- __BLOCK__ --><?php if(Route::has('register')): ?>
            <a href="<?php echo e(route('register')); ?>" class="ml-4 btn text-gray-50 rounded btn-outline ring ring-inset font-semibold focus:outline-none focus:ring-2 focus:ring-red-500" wire:navigate>
                <i class="fas fa-user-plus mr-1"></i> Register
            </a>
        <?php endif; ?> <!-- __ENDBLOCK__ -->
    <?php endif; ?> <!-- __ENDBLOCK__ -->
</div><?php /**PATH D:\Apps\sermonstory\resources\views\livewire/welcome/navigation.blade.php ENDPATH**/ ?>
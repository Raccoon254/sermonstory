<div>
    <input type="text" wire:model="search" placeholder="Search stories...">

    <button wire:click="performSearch">Search</button>
    <?php echo e($search); ?>

    <section class="mt-2 p-2">
        <!-- __BLOCK__ --><?php $__currentLoopData = $stories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $story): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="flex">
                <?php echo e($story['content']); ?>

            </div><br>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!-- __ENDBLOCK__ -->
    </section>
</div>

<?php /**PATH C:\Apps\sermonstory\resources\views/livewire/gpt-stories-search.blade.php ENDPATH**/ ?>
<x-app-layout>
    <section class="mt-2">
@livewire('livestories')

{{--        @livewire('stories')--}}
    </section>
</x-app-layout>

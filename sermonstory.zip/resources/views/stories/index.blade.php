<x-app-layout>

    <section class="mt-2">
        @livewire('stories')
    </section>
</x-app-layout>

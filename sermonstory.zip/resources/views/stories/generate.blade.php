<x-app-layout>
    <div class="mt-4">
        @livewire('gptgenerate')
    </div>
</x-app-layout>

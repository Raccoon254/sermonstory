<p>You have a new contact form submission from {{ $contact->first_name }} {{ $contact->last_name }}.</p>
<p>Email: {{ $contact->email }}</p>
<p>Phone: {{ $contact->phone }}</p>
<p>Message: {{ $contact->message }}</p>

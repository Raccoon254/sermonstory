<x-app-layout>
    <div class="grid place-items-center h-auto">
        <div class="flex items-center justify-center flex-col">
            <center class="text-[2.4rem] my-2 font-semibold mb-4">SermonStories™️
                <span class="bg-red-500 text-white">
                Coming Soon
            </span>
            </center>

            <p class="text-gray-700">
                This feature is coming soon. Please check back later.
            </p>
        </div>
    </div>
</x-app-layout>

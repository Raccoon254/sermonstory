<x-app-layout>
    <section class="mt-2 p-2">
        @livewire('gptstories')
    </section>
</x-app-layout>

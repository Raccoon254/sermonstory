<x-app-layout>
    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 mt-4">
        @livewire('generate')
    </div>
</x-app-layout>
